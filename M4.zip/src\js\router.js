/* PETZY Client-Side SPA Router (Dynamic Routes & Milestone 1 + Milestone 2 Pages) */
import { renderHome, setupHomeEvents } from './pages/home.js';
import { renderAbout, setupAboutEvents } from './pages/about.js';
import { renderServices, setupServicesEvents } from './pages/services.js';
import { renderServiceDetail, setupServiceDetailEvents } from './pages/service-detail.js';
import { renderVeterinarians, setupVeterinariansEvents } from './pages/veterinarians.js';
import { renderVeterinarianProfile, setupVeterinarianProfileEvents } from './pages/veterinarian-profile.js';
import { renderContact, setupContactEvents } from './pages/contact.js';
import { renderFaq, setupFaqEvents } from './pages/faq.js';
import { renderLogin, setupLoginEvents } from './pages/login.js';
import { renderRegister, setupRegisterEvents } from './pages/register.js';
import { renderPrivacyPolicy, setupPrivacyPolicyEvents } from './pages/privacy-policy.js';
import { renderTermsConditions, setupTermsConditionsEvents } from './pages/terms-conditions.js';
import { renderDashboard, setupDashboardEvents } from './pages/dashboard.js';
import { renderPetProfile, setupPetProfileEvents } from './pages/pet-profile.js';
import { renderScheduleAppointment, setupScheduleAppointmentEvents, resetBookingState } from './pages/schedule-appointment.js';
import { renderAdmin, setupAdminEvents } from './pages/admin.js';
import { renderAdminLogin, setupAdminLoginEvents } from './pages/admin/admin-login.js';
import { updateActiveNav } from './components/header.js';
import { getDoctorById, getServiceById } from './services/storage.js';
import { getSmartParentRoute } from './components/back-button.js';
import { getCurrentUser, isAdmin } from './services/auth.js';
import { showToast } from './components/toast.js';

const routes = {
  '/': { render: renderHome, setup: setupHomeEvents, title: 'PETZY — Because Every Paw Deserves the Best Care' },
  '/about': { render: renderAbout, setup: setupAboutEvents, title: 'About Us — PETZY Veterinary Care' },
  '/services': { render: renderServices, setup: setupServicesEvents, title: 'Services — PETZY Veterinary Hospital' },
  '/service-detail': { render: renderServiceDetail, setup: setupServiceDetailEvents, title: 'Veterinary Consultation — PETZY' },
  '/veterinarians': { render: renderVeterinarians, setup: setupVeterinariansEvents, title: 'Meet Our Veterinary Experts — PETZY' },
  '/veterinarian-profile': { render: renderVeterinarianProfile, setup: setupVeterinarianProfileEvents, title: 'Veterinarian Profile — PETZY' },
  '/contact': { render: renderContact, setup: setupContactEvents, title: 'Contact & Appointments — PETZY Veterinary Hospital' },
  '/faq': { render: renderFaq, setup: setupFaqEvents, title: 'Frequently Asked Questions — PETZY' },
  '/login': { render: renderLogin, setup: setupLoginEvents, title: 'Pet Parent Portal Sign In — PETZY' },
  '/register': { render: renderRegister, setup: setupRegisterEvents, title: 'Register New Patient Account — PETZY' },
  '/dashboard': { render: renderDashboard, setup: setupDashboardEvents, title: 'Customer Dashboard — PETZY Veterinary Care' },
  '/schedule-appointment': { render: renderScheduleAppointment, setup: setupScheduleAppointmentEvents, title: 'Schedule Veterinary Appointment — PETZY' },
  '/book-appointment': { render: renderScheduleAppointment, setup: setupScheduleAppointmentEvents, title: 'Schedule Veterinary Appointment — PETZY' },
  '/admin/login': { render: renderAdminLogin, setup: setupAdminLoginEvents, title: 'Hospital Administration Sign In — PETZY' },
  '/admin': { render: renderAdmin, setup: setupAdminEvents, title: 'Hospital Administration — PETZY' },
  '/admin/dashboard': { render: renderAdmin, setup: setupAdminEvents, title: 'Hospital Administration — PETZY' },
  '/admin/customers': { render: renderAdmin, setup: setupAdminEvents, title: 'Customer Management — PETZY Admin' },
  '/admin/services': { render: renderAdmin, setup: setupAdminEvents, title: 'Services Catalog — PETZY Admin' },
  '/admin/veterinarians': { render: renderAdmin, setup: setupAdminEvents, title: 'Veterinarians Management — PETZY Admin' },
  '/admin/availability': { render: renderAdmin, setup: setupAdminEvents, title: 'Doctor Schedules & Availability — PETZY Admin' },
  '/admin/appointments': { render: renderAdmin, setup: setupAdminEvents, title: 'Global Appointments — PETZY Admin' },
  '/admin/payments': { render: renderAdmin, setup: setupAdminEvents, title: 'Payments & Revenue Ledger — PETZY Admin' },
  '/privacy-policy': { render: renderPrivacyPolicy, setup: setupPrivacyPolicyEvents, title: 'Privacy Policy — PETZY Veterinary Care' },
  '/privacy': { render: renderPrivacyPolicy, setup: setupPrivacyPolicyEvents, title: 'Privacy Policy — PETZY Veterinary Care' },
  '/terms-conditions': { render: renderTermsConditions, setup: setupTermsConditionsEvents, title: 'Terms & Conditions — PETZY Veterinary Care' },
  '/terms': { render: renderTermsConditions, setup: setupTermsConditionsEvents, title: 'Terms & Conditions — PETZY Veterinary Care' }
};

export function navigateTo(path) {
  window.location.hash = `#${path}`;
}

let currentActiveRoute = null;

export function handleRoute() {
  const fullRawHash = window.location.hash || '#/';
  const fullHash = fullRawHash.slice(1) || '/';
  const cleanPath = fullHash.split('?')[0].split('#')[0] || '/';
  
  if (typeof window !== 'undefined') {
    window.petzyHandleRoute = handleRoute;
    window.petzyNavCount = (window.petzyNavCount || 0) + 1;
  }

  if (currentActiveRoute && currentActiveRoute !== fullHash) {
    window.petzyPreviousRoute = currentActiveRoute;
  }
  currentActiveRoute = fullHash;

  // Reset booking wizard to start from beginning when leaving or entering fresh
  if (cleanPath !== '/book-appointment' && cleanPath !== '/schedule-appointment') {
    resetBookingState();
  } else if (!fullHash.includes('?') && !fullHash.includes('paypal_success')) {
    resetBookingState();
  }

  const appRoot = document.getElementById('app-root');
  if (!appRoot) return;

  // ----------------------------------------------------
  // STRICT ROUTE & ROLE-BASED ACCESS CONTROL (RBAC) GUARD
  // ----------------------------------------------------
  const currentUser = getCurrentUser();
  const isUserAdmin = isAdmin();

  // Guard 1: Any /admin/* route (except /admin/login) requires admin role
  if (cleanPath.startsWith('/admin') && cleanPath !== '/admin/login') {
    if (!currentUser) {
      showToast('Administrative authorization required. Please sign in.', 'coral', 'fa-solid fa-shield-halved');
      window.location.hash = '#/admin/login';
      return;
    }
    if (!isUserAdmin) {
      showToast('Access Denied: Restricted to PETZY hospital administrators.', 'coral', 'fa-solid fa-ban');
      window.location.hash = '#/dashboard';
      return;
    }
  }

  // Guard 2: Customer /dashboard requires authenticated customer session (Admins redirected to admin panel)
  if (cleanPath === '/dashboard') {
    if (!currentUser) {
      showToast('Please sign in to access your customer dashboard.', 'coral', 'fa-solid fa-user-lock');
      window.location.hash = '#/login';
      return;
    }
    if (isUserAdmin) {
      window.location.hash = '#/admin/dashboard';
      return;
    }
  }

  // Guard 3: If authenticated admin visits /admin/login, redirect to /admin/dashboard
  if (cleanPath === '/admin/login' && currentUser && isUserAdmin) {
    window.location.hash = '#/admin/dashboard';
    return;
  }

  // 1. Dynamic veterinarian profile route: /veterinarians/:doctorId
  if (cleanPath.startsWith('/veterinarians/') && cleanPath.length > '/veterinarians/'.length) {
    const doctorId = cleanPath.replace('/veterinarians/', '').replace(/\/$/, '');
    const doctor = getDoctorById(doctorId);
    
    appRoot.innerHTML = renderVeterinarianProfile(doctorId);
    if (typeof setupVeterinarianProfileEvents === 'function') {
      setupVeterinarianProfileEvents();
    }

    document.title = `${doctor.name} (${doctor.title}) — PETZY`;
    updateActiveNav('/veterinarians');
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }

  // 2. Dynamic service detail route: /service-detail?id=... or /services/:serviceId
  if (cleanPath === '/service-detail' || (cleanPath.startsWith('/services/') && cleanPath.length > '/services/'.length)) {
    let serviceId = null;
    if (fullHash.includes('?id=')) {
      serviceId = fullHash.split('?id=')[1]?.split('&')[0];
    } else if (cleanPath.startsWith('/services/')) {
      serviceId = cleanPath.replace('/services/', '').replace(/\/$/, '');
    }
    const service = getServiceById(serviceId);
    
    appRoot.innerHTML = renderServiceDetail(serviceId);
    if (typeof setupServiceDetailEvents === 'function') {
      setupServiceDetailEvents();
    }

    document.title = `${service.title} — PETZY`;
    updateActiveNav('/services');
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }

  // 3. Query/Legacy based veterinarian-profile route: /veterinarian-profile?id=...
  if (cleanPath === '/veterinarian-profile') {
    let doctorId = null;
    if (fullHash.includes('?id=')) {
      doctorId = fullHash.split('?id=')[1]?.split('&')[0];
    }
    const doctor = getDoctorById(doctorId);

    appRoot.innerHTML = renderVeterinarianProfile(doctorId);
    if (typeof setupVeterinarianProfileEvents === 'function') {
      setupVeterinarianProfileEvents();
    }

    document.title = `${doctor.name} (${doctor.title}) — PETZY`;
    updateActiveNav('/veterinarians');
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }

  // 3. Dynamic Individual Pet Profile Route: /pet-profile?id=... or /pet-profile/:id
  if (cleanPath === '/pet-profile' || cleanPath.startsWith('/pet-profile/')) {
    let petId = null;
    if (fullHash.includes('?id=')) {
      petId = fullHash.split('?id=')[1]?.split('&')[0];
    } else if (cleanPath.startsWith('/pet-profile/')) {
      petId = cleanPath.replace('/pet-profile/', '').replace(/\/$/, '');
    }

    appRoot.innerHTML = renderPetProfile(petId);
    if (typeof setupPetProfileEvents === 'function') {
      setupPetProfileEvents(petId);
    }

    document.title = `Pet Health Record — PETZY`;
    updateActiveNav('/dashboard');
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }

  // 4. Standard static routes
  const route = routes[cleanPath] || routes['/'];
  appRoot.innerHTML = route.render();
  if (typeof route.setup === 'function') {
    route.setup();
  }

  // Update Page Title
  document.title = route.title;

  // Update Active Header Links
  updateActiveNav(cleanPath);

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'instant' });
}

export function initRouter() {
  window.addEventListener('hashchange', handleRoute);
  window.addEventListener('popstate', handleRoute);
  handleRoute();
}
